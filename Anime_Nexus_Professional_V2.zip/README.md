# Anime Nexus — Professional Streamlit V2

Professional web edition of Anime Nexus.

## Features
- Premium dark anime dashboard
- Watchlist with search, filters and sorting
- Episode progress tracking
- Favorites and completed library
- Schedule and reminder status
- Add/delete/update anime
- JSON persistence

## Run locally

```bash
pip install -r requirements.txt
streamlit run app.py
```

## Streamlit Cloud

Use `main` branch and `app.py` as the main file.
