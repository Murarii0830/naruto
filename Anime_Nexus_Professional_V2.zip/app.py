import streamlit as st
import json
import os
from datetime import datetime, date, time

# ============================================================
# ANIME NEXUS — PROFESSIONAL STREAMLIT V2
# ============================================================

DATA_FILE = "anime_nexus_data.json"

st.set_page_config(
    page_title="Anime Nexus",
    page_icon="✦",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ------------------------- PROFESSIONAL THEME ----------------
st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=Space+Grotesk:wght@500;600;700&display=swap');

:root {
    --bg:#07070d;
    --panel:#0d0d17;
    --card:#12121f;
    --card2:#17172a;
    --line:rgba(255,255,255,.075);
    --text:#f7f7fb;
    --muted:#8d91a6;
    --purple:#8b5cf6;
    --pink:#ec4899;
    --cyan:#22d3ee;
    --green:#22c55e;
    --yellow:#facc15;
    --red:#fb7185;
}

html, body, [class*="css"] {
    font-family:'Inter',sans-serif;
}

.stApp {
    background:
      radial-gradient(900px 500px at 78% -5%, rgba(139,92,246,.16), transparent 60%),
      radial-gradient(700px 450px at 0% 35%, rgba(34,211,238,.055), transparent 60%),
      var(--bg);
    color:var(--text);
}

.block-container {
    max-width:1450px;
    padding-top:1.4rem;
    padding-bottom:3rem;
}

[data-testid="stSidebar"] {
    background:linear-gradient(180deg,#0a0a12 0%,#08080f 100%);
    border-right:1px solid var(--line);
}

[data-testid="stSidebar"] > div:first-child {
    padding:1.25rem 1rem;
}

.brand {
    padding:5px 8px 24px;
    border-bottom:1px solid var(--line);
    margin-bottom:20px;
}
.brand-row {display:flex;align-items:center;gap:10px;}
.brand-mark {
    width:38px;height:38px;border-radius:12px;
    display:flex;align-items:center;justify-content:center;
    color:#fff;font-size:20px;font-weight:800;
    background:linear-gradient(135deg,var(--purple),var(--pink));
    box-shadow:0 10px 28px rgba(139,92,246,.28);
}
.brand-name {
    font-family:'Space Grotesk',sans-serif;
    font-size:19px;font-weight:700;letter-spacing:.4px;
}
.brand-sub {
    margin:5px 0 0 48px;
    color:var(--cyan);font-size:9px;font-weight:800;letter-spacing:4px;
}

.nav-label {
    color:#555b70;font-size:9px;font-weight:800;letter-spacing:2px;
    margin:16px 0 8px 4px;
}

div[data-testid="stSidebar"] div.stButton > button {
    border:1px solid transparent;
    background:transparent;
    color:#9da2b5;
    text-align:left;
    border-radius:12px;
    min-height:42px;
    font-weight:600;
    transition:.18s ease;
}
div[data-testid="stSidebar"] div.stButton > button:hover {
    background:rgba(139,92,246,.10);
    border-color:rgba(139,92,246,.16);
    color:#fff;
}
div[data-testid="stSidebar"] div.stButton > button[kind="primary"] {
    background:linear-gradient(90deg,rgba(139,92,246,.22),rgba(236,72,153,.10));
    border-color:rgba(139,92,246,.28);
    color:#fff;
    box-shadow:inset 3px 0 0 var(--purple);
}

.sidebar-mini {
    margin-top:20px;padding:15px;border:1px solid var(--line);
    border-radius:15px;background:rgba(255,255,255,.025);
}
.sidebar-mini-title {font-size:11px;font-weight:800;color:#ddd;}
.sidebar-mini-text {font-size:10px;color:#6f7488;margin-top:5px;line-height:1.5;}

.topbar {
    display:flex;justify-content:space-between;align-items:center;
    margin-bottom:18px;
}
.eyebrow {font-size:10px;letter-spacing:2px;color:var(--cyan);font-weight:800;}
.page-title {
    font-family:'Space Grotesk',sans-serif;
    font-size:31px;font-weight:700;letter-spacing:-.8px;color:#fff;
}
.page-sub {font-size:12px;color:var(--muted);margin-top:3px;}
.clock {
    border:1px solid var(--line);background:rgba(255,255,255,.025);
    border-radius:12px;padding:9px 13px;text-align:right;
    color:#c8ccda;font-size:10px;line-height:1.45;
}

.hero {
    position:relative;overflow:hidden;
    border:1px solid rgba(139,92,246,.22);
    border-radius:25px;
    padding:34px 36px;
    min-height:230px;
    background:
      radial-gradient(circle at 86% 20%, rgba(236,72,153,.25), transparent 25%),
      radial-gradient(circle at 70% 90%, rgba(34,211,238,.12), transparent 30%),
      linear-gradient(135deg,#17102b 0%,#11111e 52%,#10101a 100%);
    box-shadow:0 25px 70px rgba(0,0,0,.26);
}
.hero:after {
    content:"✦";
    position:absolute;right:6%;top:14%;
    font-size:150px;font-weight:800;color:rgba(139,92,246,.055);
}
.hero-kicker {
    display:inline-flex;gap:7px;align-items:center;
    padding:6px 10px;border-radius:999px;
    background:rgba(34,211,238,.08);
    color:#67e8f9;font-size:9px;font-weight:800;letter-spacing:1.5px;
}
.hero h1 {
    font-family:'Space Grotesk',sans-serif;
    font-size:42px;line-height:1.05;margin:16px 0 8px;
    letter-spacing:-1.8px;
}
.hero p {max-width:620px;color:#a7abba;font-size:13px;line-height:1.65;margin:0;}
.hero-actions {margin-top:22px;}

.stat {
    background:linear-gradient(145deg,rgba(255,255,255,.045),rgba(255,255,255,.018));
    border:1px solid var(--line);
    border-radius:18px;padding:17px 18px;min-height:118px;
    box-shadow:0 12px 35px rgba(0,0,0,.12);
}
.stat-top {display:flex;justify-content:space-between;align-items:center;}
.stat-icon {
    width:32px;height:32px;border-radius:10px;
    display:flex;align-items:center;justify-content:center;
    background:rgba(139,92,246,.12);color:#c4b5fd;
}
.stat-value {font-size:29px;font-weight:800;color:#fff;margin-top:12px;}
.stat-label {font-size:9px;letter-spacing:1.2px;font-weight:800;color:#777d92;margin-top:2px;}

.section-head {
    display:flex;justify-content:space-between;align-items:end;
    margin:26px 0 11px;
}
.section-title {font-family:'Space Grotesk',sans-serif;font-size:19px;font-weight:700;}
.section-sub {font-size:10px;color:#6f7488;margin-top:3px;}

.anime-card {
    background:linear-gradient(145deg,#141423,#10101a);
    border:1px solid var(--line);
    border-radius:18px;
    padding:17px;
    margin-bottom:11px;
    transition:.2s ease;
}
.anime-card:hover {
    border-color:rgba(139,92,246,.28);
    transform:translateY(-1px);
    box-shadow:0 15px 35px rgba(0,0,0,.18);
}
.poster {
    width:62px;height:78px;border-radius:13px;
    display:flex;align-items:center;justify-content:center;
    background:linear-gradient(145deg,#251947,#171321);
    border:1px solid rgba(255,255,255,.07);
    color:#d8ccff;font-size:24px;font-weight:800;
    box-shadow:inset 0 0 25px rgba(139,92,246,.08);
}
.anime-title {
    color:#fff;font-family:'Space Grotesk',sans-serif;
    font-size:17px;font-weight:700;
}
.meta {font-size:10px;color:#858a9e;margin-top:4px;}
.tag {
    display:inline-block;padding:4px 8px;border-radius:999px;
    background:rgba(139,92,246,.10);color:#c4b5fd;
    font-size:8px;font-weight:800;margin-right:4px;
}
.progress-label {
    display:flex;justify-content:space-between;
    font-size:9px;color:#777d92;margin:12px 0 5px;
}
.progress-label b {color:#d8dbea;}

.schedule-card {
    background:linear-gradient(145deg,#131322,#0f0f18);
    border:1px solid var(--line);border-radius:16px;
    padding:15px 17px;margin-bottom:9px;
}
.schedule-time {color:var(--cyan);font-size:14px;font-weight:800;}
.schedule-name {color:#fff;font-weight:700;font-size:13px;}
.schedule-meta {color:#777d92;font-size:9px;margin-top:3px;}

.empty {
    text-align:center;padding:45px 20px;border:1px dashed rgba(255,255,255,.10);
    border-radius:18px;background:rgba(255,255,255,.015);
}
.empty-icon {font-size:35px;opacity:.7;}
.empty-title {font-weight:800;color:#ddd;margin-top:8px;}
.empty-text {font-size:11px;color:#70758a;margin-top:4px;}

div[data-testid="stButton"] > button {
    border-radius:10px;
    border:1px solid rgba(255,255,255,.08);
    background:#171727;
    color:#dfe2ec;
    font-weight:700;
    min-height:36px;
    transition:.18s ease;
}
div[data-testid="stButton"] > button:hover {
    border-color:rgba(139,92,246,.45);
    background:#20183a;color:#fff;
}
div[data-testid="stFormSubmitButton"] > button {
    border:0;border-radius:11px;
    background:linear-gradient(90deg,var(--purple),var(--pink));
    color:white;font-weight:800;
    min-height:42px;
}
div[data-testid="stProgress"] > div > div > div > div {
    background:linear-gradient(90deg,var(--purple),var(--pink));
}
[data-testid="stMetric"] {
    background:#12121f;border:1px solid var(--line);
    border-radius:14px;padding:12px;
}
.stTextInput input, .stNumberInput input, .stDateInput input, .stTimeInput input {
    background:#11111c!important;border:1px solid var(--line)!important;
    color:#fff!important;border-radius:10px!important;
}
[data-baseweb="select"] > div {
    background:#11111c!important;border-color:var(--line)!important;border-radius:10px!important;
}
div[data-testid="stExpander"] {
    background:rgba(255,255,255,.018);
    border:1px solid var(--line);border-radius:15px;
}
hr {border-color:var(--line);}
footer {visibility:hidden;}

@media (max-width:800px) {
    .hero {padding:25px 22px;min-height:200px;}
    .hero h1 {font-size:31px;}
    .page-title {font-size:25px;}
    .clock {display:none;}
}
</style>
""", unsafe_allow_html=True)

# ------------------------- DATA ------------------------------

def default_data():
    today = datetime.now().strftime("%d-%m-%Y")
    return [
        {"anime":"Solo Leveling","episode":18,"total":25,"status":"Watching","genre":"Action","priority":"High","favorite":True,"date":today,"time":"20:00","completed":False},
        {"anime":"One Piece","episode":1150,"total":1200,"status":"Watching","genre":"Adventure","priority":"High","favorite":True,"date":today,"time":"21:00","completed":False},
        {"anime":"Demon Slayer","episode":12,"total":12,"status":"Completed","genre":"Action","priority":"Medium","favorite":False,"date":today,"time":"22:00","completed":True},
    ]

def save_data(data):
    try:
        with open(DATA_FILE,"w",encoding="utf-8") as f:
            json.dump(data,f,indent=2,ensure_ascii=False)
    except Exception as exc:
        st.error(f"Could not save data: {exc}")

def load_data():
    if os.path.exists(DATA_FILE):
        try:
            with open(DATA_FILE,"r",encoding="utf-8") as f:
                d=json.load(f)
                if isinstance(d,list):
                    return d
        except Exception:
            pass
    d=default_data()
    save_data(d)
    return d

if "anime_list" not in st.session_state:
    st.session_state.anime_list=load_data()
if "page" not in st.session_state:
    st.session_state.page="Dashboard"

def persist():
    save_data(st.session_state.anime_list)

def progress_for(a):
    total=max(int(a.get("total",0) or 0),1)
    ep=max(int(a.get("episode",0) or 0),0)
    return min(ep/total,1)

def initials(name):
    words=name.strip().split()
    return "".join(w[0] for w in words[:2]).upper() or "AN"

def nav(page):
    st.session_state.page=page
    st.rerun()

def increase_episode(i):
    a=st.session_state.anime_list[i]
    if a["episode"] < a["total"]:
        a["episode"]+=1
        if a["episode"]>=a["total"]:
            a["completed"]=True
            a["status"]="Completed"
        persist()
        st.toast(f"{a['anime']} • Episode {a['episode']}",icon="▶️")
    else:
        st.toast("Already at the final episode.",icon="✓")

def complete(i):
    a=st.session_state.anime_list[i]
    a["episode"]=a["total"]
    a["completed"]=True
    a["status"]="Completed"
    persist()
    st.toast(f"{a['anime']} completed!",icon="🏆")

def favorite(i):
    a=st.session_state.anime_list[i]
    a["favorite"]=not a["favorite"]
    persist()

def delete(i):
    name=st.session_state.anime_list[i]["anime"]
    st.session_state.anime_list.pop(i)
    persist()
    st.toast(f"{name} removed",icon="🗑️")

# ------------------------- SIDEBAR ---------------------------
with st.sidebar:
    st.markdown("""
    <div class="brand">
      <div class="brand-row">
        <div class="brand-mark">✦</div>
        <div class="brand-name">ANIME NEXUS</div>
      </div>
      <div class="brand-sub">ULTIMATE ANIME MANAGER</div>
    </div>
    """,unsafe_allow_html=True)

    st.markdown('<div class="nav-label">LIBRARY</div>',unsafe_allow_html=True)
    pages=[("⌂","Dashboard"),("▶","Watchlist"),("◷","Schedule"),("★","Favorites"),("✓","Completed")]
    for icon,name in pages:
        if st.button(f"{icon}   {name}",key=f"nav_{name}",use_container_width=True,
                     type="primary" if st.session_state.page==name else "secondary"):
            nav(name)

    st.markdown('<div class="nav-label">QUICK INFO</div>',unsafe_allow_html=True)
    data=st.session_state.anime_list
    watching=sum(1 for a in data if a["status"]=="Watching" and not a["completed"])
    completed=sum(1 for a in data if a["completed"])
    st.markdown(f"""
    <div class="sidebar-mini">
      <div class="sidebar-mini-title">YOUR LIBRARY</div>
      <div class="sidebar-mini-text">{len(data)} anime · {watching} watching · {completed} completed</div>
    </div>
    """,unsafe_allow_html=True)
    st.markdown('<div class="sidebar-mini"><div class="sidebar-mini-title">NEXUS MODE</div><div class="sidebar-mini-text">Track your progress. Own your watchlist. Never miss an episode.</div></div>',unsafe_allow_html=True)

# ------------------------- TOPBAR -----------------------------
page=st.session_state.page
now=datetime.now()
st.markdown(f"""
<div class="topbar">
  <div>
    <div class="eyebrow">ANIME NEXUS / {page.upper()}</div>
    <div class="page-title">{page}</div>
    <div class="page-sub">Your personal anime command center.</div>
  </div>
  <div class="clock">{now.strftime("%A")}<br><b>{now.strftime("%d %B %Y")}</b> · {now.strftime("%I:%M %p")}</div>
</div>
""",unsafe_allow_html=True)

# ========================= DASHBOARD =========================
if page=="Dashboard":
    data=st.session_state.anime_list
    total=len(data)
    watching=sum(1 for a in data if a["status"]=="Watching" and not a["completed"])
    completed=sum(1 for a in data if a["completed"])
    favorites=sum(1 for a in data if a["favorite"])

    st.markdown("""
    <div class="hero">
      <span class="hero-kicker">✦ PERSONAL ANIME COMMAND CENTER</span>
      <h1>Welcome back,<br>Anime Watcher.</h1>
      <p>Everything you watch, track and schedule — organized in one focused workspace.</p>
    </div>
    """,unsafe_allow_html=True)

    st.write("")
    cols=st.columns(4)
    stats=[("◈",total,"TOTAL ANIME"),("▶",watching,"WATCHING"),("✓",completed,"COMPLETED"),("★",favorites,"FAVORITES")]
    for col,(icon,val,label) in zip(cols,stats):
        with col:
            st.markdown(f"""
            <div class="stat">
              <div class="stat-top"><div class="stat-icon">{icon}</div></div>
              <div class="stat-value">{val}</div><div class="stat-label">{label}</div>
            </div>
            """,unsafe_allow_html=True)

    left,right=st.columns([1.45,1],gap="large")

    with left:
        st.markdown('<div class="section-head"><div><div class="section-title">Continue Watching</div><div class="section-sub">Jump back into your current series</div></div></div>',unsafe_allow_html=True)
        items=[(i,a) for i,a in enumerate(data) if a["status"]=="Watching" and not a["completed"]][:5]
        if not items:
            st.markdown('<div class="empty"><div class="empty-icon">◌</div><div class="empty-title">Nothing in progress</div><div class="empty-text">Add an anime to your watchlist to start tracking it.</div></div>',unsafe_allow_html=True)
        for i,a in items:
            pct=progress_for(a)
            st.markdown(f"""
            <div class="anime-card">
              <div style="display:flex;gap:14px;align-items:center">
                <div class="poster">{initials(a['anime'])}</div>
                <div style="flex:1">
                  <div class="anime-title">{a['anime']}</div>
                  <div class="meta">{a['genre']} · {a['priority']} priority</div>
                  <div class="progress-label"><span>EPISODE PROGRESS</span><b>{a['episode']} / {a['total']} · {int(pct*100)}%</b></div>
                </div>
              </div>
            </div>
            """,unsafe_allow_html=True)
            st.progress(pct)

    with right:
        st.markdown('<div class="section-head"><div><div class="section-title">Today</div><div class="section-sub">Your scheduled watch sessions</div></div></div>',unsafe_allow_html=True)
        today_str=now.strftime("%d-%m-%Y")
        today_items=sorted([a for a in data if a.get("date")==today_str],key=lambda x:x.get("time","99:99"))
        if not today_items:
            st.markdown('<div class="empty"><div class="empty-icon">◷</div><div class="empty-title">Clear schedule</div><div class="empty-text">No episodes scheduled for today.</div></div>',unsafe_allow_html=True)
        for a in today_items[:5]:
            state="COMPLETED" if a["completed"] else "UP NEXT"
            st.markdown(f"""
            <div class="schedule-card">
              <div style="display:flex;align-items:center;gap:14px">
                <div class="schedule-time">{a['time']}</div>
                <div style="flex:1"><div class="schedule-name">{a['anime']}</div><div class="schedule-meta">Episode {a['episode']} · {a['genre']}</div></div>
                <span class="tag">{state}</span>
              </div>
            </div>
            """,unsafe_allow_html=True)

# ========================= WATCHLIST =========================
elif page=="Watchlist":
    st.markdown("""
    <div class="hero">
      <span class="hero-kicker">◈ YOUR LIBRARY</span>
      <h1>Watchlist.</h1>
      <p>Search, filter and manage every series in your personal anime library.</p>
    </div>
    """,unsafe_allow_html=True)

    with st.expander("＋  ADD NEW ANIME",expanded=False):
        with st.form("add_form",clear_on_submit=True):
            c1,c2=st.columns(2)
            with c1:
                name=st.text_input("Anime name",placeholder="e.g. Attack on Titan")
                ep=st.number_input("Current episode",min_value=0,value=1,step=1)
                total=st.number_input("Total episodes",min_value=1,value=12,step=1)
                genre=st.text_input("Genre",value="Action")
            with c2:
                d=st.date_input("Reminder date",value=date.today())
                t=st.time_input("Reminder time",value=time(20,0))
                priority=st.selectbox("Priority",["Low","Medium","High"])
                fav=st.checkbox("Add to favorites")
            submit=st.form_submit_button("ADD TO WATCHLIST  →",use_container_width=True)
            if submit:
                if not name.strip():
                    st.error("Please enter an anime name.")
                else:
                    e=min(int(ep),int(total))
                    st.session_state.anime_list.append({
                        "anime":name.strip(),"episode":e,"total":int(total),
                        "status":"Completed" if e>=int(total) else "Watching",
                        "genre":genre.strip() or "Unknown","priority":priority,
                        "favorite":fav,"date":d.strftime("%d-%m-%Y"),
                        "time":t.strftime("%H:%M"),"completed":e>=int(total)
                    })
                    persist()
                    st.success(f"{name.strip()} added.")
                    st.rerun()

    q=st.text_input("⌕  Search your library",placeholder="Search anime...")
    f1,f2,f3=st.columns([1,1,2])
    status=f1.selectbox("Status",["All","Watching","Completed"])
    fav_filter=f2.selectbox("Favorites",["All","Favorites only"])
    sort=f3.selectbox("Sort by",["Recently added","Name A–Z","Progress","Priority"])

    filtered=[]
    for i,a in enumerate(st.session_state.anime_list):
        if q.strip().lower() not in a["anime"].lower(): continue
        if status=="Watching" and (a["status"]!="Watching" or a["completed"]): continue
        if status=="Completed" and not a["completed"]: continue
        if fav_filter=="Favorites only" and not a["favorite"]: continue
        filtered.append((i,a))

    if sort=="Name A–Z": filtered.sort(key=lambda x:x[1]["anime"].lower())
    elif sort=="Progress": filtered.sort(key=lambda x:progress_for(x[1]),reverse=True)
    elif sort=="Priority": filtered.sort(key=lambda x:{"High":0,"Medium":1,"Low":2}.get(x[1]["priority"],3))

    st.caption(f"{len(filtered)} title(s) in view")

    if not filtered:
        st.markdown('<div class="empty"><div class="empty-icon">⌕</div><div class="empty-title">No matches</div><div class="empty-text">Try another search or filter.</div></div>',unsafe_allow_html=True)

    for i,a in filtered:
        pct=progress_for(a)
        status_text="COMPLETED" if a["completed"] else "WATCHING"
        st.markdown(f"""
        <div class="anime-card">
          <div style="display:flex;gap:15px;align-items:center">
            <div class="poster">{initials(a['anime'])}</div>
            <div style="flex:1">
              <div class="anime-title">{a['anime']} {'★' if a['favorite'] else ''}</div>
              <div class="meta">{a['genre']} · {a['priority']} priority · {status_text}</div>
              <div class="progress-label"><span>EPISODE PROGRESS</span><b>{a['episode']} / {a['total']} · {int(pct*100)}%</b></div>
            </div>
          </div>
        </div>
        """,unsafe_allow_html=True)
        st.progress(pct)
        b1,b2,b3,b4=st.columns(4)
        if b1.button("▶ + Episode",key=f"ep{i}",use_container_width=True):
            increase_episode(i); st.rerun()
        if b2.button("✓ Complete",key=f"co{i}",use_container_width=True):
            complete(i); st.rerun()
        if b3.button("★ Favorite" if not a["favorite"] else "☆ Unfavorite",key=f"fa{i}",use_container_width=True):
            favorite(i); st.rerun()
        if b4.button("Delete",key=f"de{i}",use_container_width=True):
            delete(i); st.rerun()

# ========================= SCHEDULE ==========================
elif page=="Schedule":
    st.markdown("""
    <div class="hero">
      <span class="hero-kicker">◷ WATCH PLANNER</span>
      <h1>Schedule.</h1>
      <p>Plan your watch sessions and keep your next episodes visible.</p>
    </div>
    """,unsafe_allow_html=True)

    selected=st.date_input("View date",value=date.today())
    key=selected.strftime("%d-%m-%Y")
    scheduled=sorted([a for a in st.session_state.anime_list if a.get("date")==key],key=lambda x:x.get("time","99:99"))
    if not scheduled:
        st.markdown('<div class="empty"><div class="empty-icon">◷</div><div class="empty-title">No sessions planned</div><div class="empty-text">Add a reminder from your Watchlist.</div></div>',unsafe_allow_html=True)
    for a in scheduled:
        badge="COMPLETED" if a["completed"] else "UP NEXT"
        st.markdown(f"""
        <div class="schedule-card">
          <div style="display:flex;align-items:center;gap:18px">
            <div class="schedule-time">{a['time']}</div>
            <div style="flex:1"><div class="schedule-name">{a['anime']}</div><div class="schedule-meta">Episode {a['episode']} / {a['total']} · {a['genre']}</div></div>
            <span class="tag">{badge}</span>
          </div>
        </div>
        """,unsafe_allow_html=True)

    st.markdown("---")
    st.markdown("### 🔔 Reminder status")
    current=now.strftime("%d-%m-%Y")
    current_time=now.strftime("%H:%M")
    due=[a for a in st.session_state.anime_list if a.get("date")==current and a.get("time")==current_time and not a.get("completed")]
    if due:
        for a in due: st.warning(f"🔔 Time to continue **{a['anime']}** — Episode {a['episode']}.")
    else:
        st.success("No reminder is due at this exact minute.")
    st.caption("Web reminders appear when the app is open/refreshed; they are not background phone/Windows push notifications.")

# ========================= FAVORITES ========================
elif page=="Favorites":
    st.markdown("""
    <div class="hero">
      <span class="hero-kicker">★ YOUR PICKS</span>
      <h1>Favorites.</h1>
      <p>The titles that earned a permanent place in your Nexus.</p>
    </div>
    """,unsafe_allow_html=True)
    favs=[(i,a) for i,a in enumerate(st.session_state.anime_list) if a["favorite"]]
    if not favs:
        st.markdown('<div class="empty"><div class="empty-icon">★</div><div class="empty-title">No favorites yet</div><div class="empty-text">Star titles from your Watchlist.</div></div>',unsafe_allow_html=True)
    for i,a in favs:
        pct=progress_for(a)
        st.markdown(f"""
        <div class="anime-card">
          <div style="display:flex;gap:15px;align-items:center">
            <div class="poster">{initials(a['anime'])}</div>
            <div style="flex:1"><div class="anime-title">{a['anime']} ★</div><div class="meta">{a['genre']} · {a['status']}</div><div class="progress-label"><span>PROGRESS</span><b>{a['episode']} / {a['total']}</b></div></div>
          </div>
        </div>
        """,unsafe_allow_html=True)
        st.progress(pct)
        if st.button("☆ Remove from favorites",key=f"rf{i}"):
            favorite(i); st.rerun()

# ========================= COMPLETED ========================
elif page=="Completed":
    st.markdown("""
    <div class="hero">
      <span class="hero-kicker">✓ FINISHED COLLECTION</span>
      <h1>Completed.</h1>
      <p>Your finished series, preserved as part of your anime journey.</p>
    </div>
    """,unsafe_allow_html=True)
    done=[a for a in st.session_state.anime_list if a["completed"]]
    if not done:
        st.markdown('<div class="empty"><div class="empty-icon">✓</div><div class="empty-title">Nothing completed yet</div><div class="empty-text">Finish an anime from your Watchlist and it will appear here.</div></div>',unsafe_allow_html=True)
    for a in done:
        st.markdown(f"""
        <div class="anime-card">
          <div style="display:flex;gap:15px;align-items:center">
            <div class="poster">✓</div>
            <div style="flex:1"><div class="anime-title">{a['anime']}</div><div class="meta">{a['total']} episodes · {a['genre']} · {a['priority']} priority</div></div>
            <span class="tag">COMPLETED</span>
          </div>
        </div>
        """,unsafe_allow_html=True)

st.markdown('<div style="text-align:center;padding:38px 0 8px;color:#454a5d;font-size:9px;letter-spacing:1px;">ANIME NEXUS  •  PYTHON + STREAMLIT  •  YOUR ANIME. YOUR JOURNEY.</div>',unsafe_allow_html=True)
